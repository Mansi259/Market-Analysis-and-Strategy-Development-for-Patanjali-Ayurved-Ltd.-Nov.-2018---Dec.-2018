import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("data/patanjali_market_data.csv")

print(data.head())

plt.plot(data["Year"], data["Patanjali"], label="Patanjali")
plt.plot(data["Year"], data["Dabur"], label="Dabur")
plt.plot(data["Year"], data["Himalaya"], label="Himalaya")
plt.plot(data["Year"], data["ITC"], label="ITC")

plt.xlabel("Year")
plt.ylabel("Market Share (%)")
plt.title("Market Share Comparison")
plt.legend()
plt.show()
